// src/app/router.jsx
import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import { PublicLayout } from "../shared/components/layouts/PublicLayout.jsx";
import { AdminLayout } from "../shared/components/layouts/AdminLayout.jsx";

// ProtectedRoute
import { ProtectedRoute } from "../shared/components/routing/ProtectedRoute.jsx";

// Páginas
import { LandingPage } from "../features/public/pages/LandingPage.jsx";
import { LoginPage } from "../features/auth/pages/LoginPage.jsx";
import { RegisterPage } from "../features/auth/pages/RegisterPage.jsx";
import { ForgotPasswordPage } from "../features/auth/pages/ForgotPasswordPage.jsx";
import { ResetPasswordPage } from "../features/auth/pages/ResetPasswordPage.jsx";
import { DemoBodaPage } from "../features/bodas/pages/DemoBodaPage.jsx";
import { AdminDashboardPage } from "../features/admin/pages/AdminDashboardPage.jsx";
import { BodaDashboardPage } from "../features/bodas/pages/BodaDashboardPage.jsx";
import { BodaConfigPage } from "../features/bodas/pages/BodaConfigPage";
import BodaPublicPage from "../features/public/pages/BodaPublicPage";
import DomainBodaPage from "../features/public/pages/DomainBodaPage.jsx";
import { UserSettingsPage } from "../features/user/pages/UserSettingsPage.jsx";
import { BodaInvitadosPage } from "../features/bodas/pages/BodaInvitadosPage.jsx";
import { RsvpPage } from "../features/public/pages/RsvpPage.jsx";
import FullCardDesignerPage from "../features/bodas/pages/FullCardDesignerPage.jsx";
import SuperadminDashboardPage from "../features/superadmin/pages/SuperadminDashboardPage.jsx";
import LogsAuditoriaPage from "../features/superadmin/pages/LogsAuditoriaPage.jsx";
import GestionUsuariosPage from "../features/superadmin/pages/GestionUsuariosPage.jsx";
import GestionBodasPage from "../features/superadmin/pages/GestionBodasPage.jsx";
import IpsBloqueadasPage from "../features/superadmin/pages/IpsBloqueadasPage.jsx";
import SesionesActivasPage from "../features/superadmin/pages/SesionesActivasPage.jsx";

// Hook para detectar dominio personalizado
import { useDomainDetection } from "../shared/hooks/useDomainDetection.js";

// Si no tienes NotFound aún, puedes crearlo luego.
function NotFoundPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50">
      <div className="bg-white border border-slate-200 rounded-xl px-6 py-4 shadow-sm">
        <h1 className="text-xl font-bold text-slate-900 mb-1">
          404 – Página no encontrada
        </h1>
        <p className="text-sm text-slate-600">
          La ruta solicitada no existe en la plataforma de bodas.
        </p>
      </div>
    </div>
  );
}

/**
 * Componente envolvente que detecta si estamos en un dominio personalizado
 * y sirve DomainBodaPage en lugar de LandingPage.
 */
function HomeOrDomainBoda() {
  const { isDomainBoda } = useDomainDetection();
  return isDomainBoda ? <DomainBodaPage /> : <LandingPage />;
}

export function AppRouter() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Rutas públicas con layout general */}
        <Route element={<PublicLayout />}>
          {/* "/" → LandingPage si es dominio base, DomainBodaPage si es dominio personalizado */}
          <Route path="/" element={<HomeOrDomainBoda />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/registro" element={<RegisterPage />} />
          <Route path="/forgot-password" element={<ForgotPasswordPage />} />
          <Route path="/reset-password" element={<ResetPasswordPage />} />
          <Route path="/demo-boda/:slug" element={<DemoBodaPage />} />
          <Route path="/rsvp/:codigo" element={<RsvpPage />} />
        </Route>

        {/* RUTA PÚBLICA DE LA BODA REAL (FASE 8)
            No usa PublicLayout ni AdminLayout para que la boda
            se vea "limpia", solo con su propia plantilla.
         */}
        <Route path="/boda/:slug" element={<BodaPublicPage />} />

        {/* ===================== ÁREA PRIVADA ===================== */}

        {/* SUPERADMIN */}
        <Route
          element={
            <ProtectedRoute allowedRoles={["superadmin"]}>
              <AdminLayout />
            </ProtectedRoute>
          }
        >
          <Route path="/admin" element={<AdminDashboardPage />} />
          <Route path="/admin/dashboard-analitico" element={<SuperadminDashboardPage />} />
          <Route path="/admin/logs-auditoria" element={<LogsAuditoriaPage />} />
          <Route path="/admin/usuarios" element={<GestionUsuariosPage />} />
          <Route path="/admin/bodas" element={<GestionBodasPage />} />
          <Route path="/admin/ips-bloqueadas" element={<IpsBloqueadasPage />} />
          <Route path="/admin/sesiones-activas" element={<SesionesActivasPage />} />
          {/* Más adelante: /admin/bodas, /admin/planes, /admin/plantillas, etc. */}
        </Route>

        {/* PANEL ADMIN_BODA (y opcionalmente SUPERADMIN) */}
        <Route
          path="/panel"
          element={
            <ProtectedRoute allowedRoles={["admin_boda", "superadmin"]}>
              <AdminLayout />
            </ProtectedRoute>
          }
        >
          <Route index element={<BodaDashboardPage />} />
          <Route path="configuracion" element={<BodaConfigPage />} />
          <Route path="invitados" element={<BodaInvitadosPage />} />
          <Route path="disenar-tarjeta" element={<FullCardDesignerPage />} />
          <Route path="ajustes" element={<UserSettingsPage />} />
          {/* Más adelante: /panel/fotos, /panel/estadisticas, etc. */}
        </Route>

        {/* 404 genérico */}
        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </BrowserRouter>
  );
}
